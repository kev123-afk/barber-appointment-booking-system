# Barber Appointment Booking System

A beginner-friendly, responsive barber appointment booking demo built with HTML, CSS, and vanilla JavaScript.

## Features

- Choose a service, barber, date, and appointment time.
- Displays available time slots from 9:00 AM to 6:00 PM.
- Checks for overlapping bookings for the same barber.
- Saves demo bookings in the browser using `localStorage`.
- Responsive layout for phones, tablets, and desktops.
- Kenyan shilling service prices.

## Technologies

- HTML5
- CSS3
- JavaScript
- Browser `localStorage`

## Run the project

1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Fill in the booking form and confirm an appointment.

No build tools or installation are required.

## Important limitations

This is a **front-end demo**, not a production booking service. Bookings are saved only in the current browser and are not shared between customers or devices. `localStorage` cannot reliably prevent two different devices from booking the same slot at the same time.

For a real business, add a backend API and shared database (for example, Node.js or Laravel with PostgreSQL or MySQL). The backend must check availability and save the booking atomically, using a transaction or suitable locking/constraints. Add authentication, server-side validation, privacy safeguards, backups, and deployment configuration before using it with real customers.

## Suggested future improvements

- Connect to a shared database.
- Admin dashboard for barbers and appointments.
- Customer cancellation and rescheduling.
- SMS or email reminders.
- Authentication and role-based access.
- Deployment to a hosting provider.

## License

This starter project is provided for learning and customization.
