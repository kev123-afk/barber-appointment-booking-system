const form = document.querySelector("#booking-form");
const dateInput = document.querySelector("#date");
const timeSelect = document.querySelector("#time");
const message = document.querySelector("#form-message");
const appointmentsList = document.querySelector("#appointments-list");
const clearButton = document.querySelector("#clear-bookings");

const STORAGE_KEY = "barberbook-demo-appointments";
const services = {
  "Haircut": { price: 300, duration: 30 },
  "Beard trim": { price: 150, duration: 15 },
  "Haircut + Beard": { price: 400, duration: 45 }
};

function getBookings() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveBookings(bookings) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
}

function minutes(time) {
  const [hours, mins] = time.split(":").map(Number);
  return hours * 60 + mins;
}

function formatTime(time) {
  const [hours, mins] = time.split(":").map(Number);
  const suffix = hours >= 12 ? "PM" : "AM";
  const displayHour = hours % 12 || 12;
  return `${displayHour}:${String(mins).padStart(2, "0")} ${suffix}`;
}

function generateTimeOptions() {
  const selectedDate = dateInput.value;
  const previousValue = timeSelect.value;
  timeSelect.innerHTML = '<option value="">Choose a time</option>';
  if (!selectedDate) return;

  const now = new Date();
  const today = new Date().toISOString().slice(0, 10);
  const bookings = getBookings();
  const service = services[document.querySelector("#service").value];

  for (let start = 9 * 60; start + service.duration <= 18 * 60; start += 30) {
    const hours = Math.floor(start / 60);
    const mins = start % 60;
    const value = `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
    const barber = document.querySelector("#barber").value;
    const collides = bookings.some((booking) => {
      if (booking.date !== selectedDate || booking.barber !== barber) return false;
      const existingStart = minutes(booking.time);
      const existingEnd = existingStart + services[booking.service].duration;
      return start < existingEnd && start + service.duration > existingStart;
    });
    const inPast = selectedDate < today || (selectedDate === today && start <= now.getHours() * 60 + now.getMinutes());
    if (!collides && !inPast) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = formatTime(value);
      timeSelect.appendChild(option);
    }
  }

  if ([...timeSelect.options].some(option => option.value === previousValue)) {
    timeSelect.value = previousValue;
  }
  if (timeSelect.options.length === 1) {
    timeSelect.innerHTML = '<option value="">No available times — choose another date or barber</option>';
  }
}

function showMessage(text, type) {
  message.textContent = text;
  message.className = `message ${type}`;
}

function renderBookings() {
  const bookings = getBookings().sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
  appointmentsList.innerHTML = "";
  if (bookings.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No appointments yet. Use the form above to make a demo booking.";
    appointmentsList.appendChild(empty);
    return;
  }

  bookings.forEach((booking) => {
    const card = document.createElement("article");
    card.className = "appointment-card";
    const heading = document.createElement("h3");
    heading.textContent = `${booking.service} — KSh ${services[booking.service].price}`;
    const details = document.createElement("p");
    details.textContent = `${booking.date} at ${formatTime(booking.time)} · Barber ${booking.barber}`;
    const customer = document.createElement("p");
    customer.textContent = `Customer: ${booking.customer}`;
    card.append(heading, details, customer);
    appointmentsList.appendChild(card);
  });
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const booking = {
    id: (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
    customer: String(data.get("customer")).trim(),
    phone: String(data.get("phone")).trim(),
    service: String(data.get("service")),
    barber: String(data.get("barber")),
    date: String(data.get("date")),
    time: String(data.get("time"))
  };

  if (!booking.time) {
    showMessage("Please choose an available time.", "error");
    return;
  }

  // Recheck immediately before saving to catch a stale slot in this browser.
  const duration = services[booking.service].duration;
  const start = minutes(booking.time);
  const conflict = getBookings().some((existing) => {
    if (existing.date !== booking.date || existing.barber !== booking.barber) return false;
    const existingStart = minutes(existing.time);
    const existingEnd = existingStart + services[existing.service].duration;
    return start < existingEnd && start + duration > existingStart;
  });

  if (conflict) {
    showMessage("That slot was just taken. Please choose another time.", "error");
    generateTimeOptions();
    return;
  }

  const bookings = getBookings();
  bookings.push(booking);
  saveBookings(bookings);
  renderBookings();
  showMessage("Appointment saved on this device. This is a demo confirmation.", "success");
  form.reset();
  dateInput.min = new Date().toISOString().slice(0, 10);
  timeSelect.innerHTML = '<option value="">Choose a date first</option>';
});

dateInput.min = new Date().toISOString().slice(0, 10);
dateInput.addEventListener("change", generateTimeOptions);
document.querySelector("#barber").addEventListener("change", generateTimeOptions);
document.querySelector("#service").addEventListener("change", generateTimeOptions);

clearButton.addEventListener("click", () => {
  if (confirm("Clear all demo appointments saved in this browser?")) {
    localStorage.removeItem(STORAGE_KEY);
    renderBookings();
    generateTimeOptions();
    showMessage("Demo appointments cleared.", "success");
  }
});

renderBookings();
